package com.esliceu.movie.models;

public enum AuthorizationState{
    ACEPTED, PENDING, DECLINED
}
