package com.esliceu.movie.exceptions;

public class PasswordToShortException extends Exception {
    public PasswordToShortException(String message) {
        super(message);
    }
}
